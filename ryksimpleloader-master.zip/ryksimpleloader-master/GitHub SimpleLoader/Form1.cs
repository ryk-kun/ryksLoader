﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ManualMapInjection.Injection;
using System.Net;
using System.IO;
using System.Diagnostics;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case 0x84:
                    base.WndProc(ref m);
                    if ((int)m.Result == 0x1)
                        m.Result = (IntPtr)0x2;
                    return;
            }

            base.WndProc(ref m);
        }
        public Form1()
        {
            InitializeComponent();
        }

        string HWID;

        private void Form1_Load(object sender, EventArgs e)
        {
            HWID = System.Security.Principal.WindowsIdentity.GetCurrent().User.Value; //changing the variable "HWID (String)" to the WindowsIdentity Value, you can use any other forms of HWID, you can even use MAC/IP (Not recommended)
            textBox1.Text = HWID;
            textBox1.ReadOnly = true;
            checkonline();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            checkonline();
            WebClient wb = new WebClient();
            string HWIDLIST = wb.DownloadString("HWID List URL"); //replace "HWID List URL" with a raw text file example: https://myurl.com/raw/hwid.txt
            if (HWIDLIST.Contains(textBox1.Text)) //you can add a "!" before the "HWIDLIST" and after the "if (" to make it into a blacklist HWID system instead of a whitelist HWID system
            {
                string mainpath = "D\\loader-settings.dll"; //you can change the path to wherever you want but just remember to use "\\" instead of just one "\"
                wb.DownloadFile("DLL URL", mainpath); //replace "DLL URL" with the URL to directly download your DLL example: http://myurl.com/mydll.dll
                var name = "csgo"; //replace this with any game you want for example:csgo, as its shown
                var target = Process.GetProcessesByName(name).FirstOrDefault();
                var path = mainpath;
                var file = File.ReadAllBytes(path);

                //checking if the DLL isn't found
                if (!File.Exists(path))
                {
                    MessageBox.Show("Error: the loader is old! Download a newer version and try again."); //change this to whatever you want just made it look more proffesional 8)
                    return;
                }

                bool result = gh.ghapi.InjectDLL(mainpath, "csgo.exe");
                this.Close();
                return;
            }
            else
            {
                MessageBox.Show("Error: your HWID was nowhere to be found!"); //change this to whatever you want too.
            }
        }

        private void checkonline()
        {
            try
            {
                using (var client = new WebClient())
                {
                    using (client.OpenRead("https://google.com/")) //checking if google is online so the cheats DLL can be downloaded.
                    {
                        label1.ForeColor = Color.OrangeRed;
                        label1.Text = ("online");
                    }
                }
            }
            catch
            {
                label1.ForeColor = Color.Red; //if it does not get a response (This means the user is offline or google is down for some reason) it will Exit the application, you can stop this by removing "Application.Exit();"
                label1.Text = ("offline");
                Application.Exit();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(HWID);
            button2.Enabled = false;
            button2.Text = "hwid copied";
        }
    }
}
